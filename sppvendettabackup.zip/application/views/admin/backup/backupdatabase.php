<div class="col-md-12 col-sm-12 col-xs-12 main post-inherit">
    <div class="x_panel post-inherit">
        <h3 class="">
            Backup Database
            
        </h3>
        <br>
        <form method="POST" action="<?=base_url()?>backup/proses_backupdatabase">
            <div class="form-group">
                <label>Keterangan:</label>
                <input type="text" class="form-control" name="keterangan">
            </div>
            
            <button class="btn btn-primary">Proses</button>
        </form>

        
    
    </div>
</div>
