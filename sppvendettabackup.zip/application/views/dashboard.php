<div class="col-md-12 col-sm-12 col-xs-12 main post-inherit">
    <div class="x_panel post-inherit">

        <!-- Indicates a successful or positive action -->

        <div class="strong">
            <h1>Sistem Informasi Pembayaran SPP</h1>
         	<hr/>

			<br><br><br>
			<br>
			
			<br>
			<?php echo pretty_date(date('Y-m-d'), 'l, d F Y',FALSE) ?> 
		</div>
	</div>
</div>
<style type="text/css">
 .upper { text-transform: uppercase; }
 .lower { text-transform: lowercase; }
 .cap   { text-transform: capitalize; }
 .small { font-variant:   small-caps; }
</style>